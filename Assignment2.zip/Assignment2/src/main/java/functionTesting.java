
import java.util.Scanner;



public class functionTesting {
    public static void main(String[] args){
    
        // Create the factory object
		product produce = new product();
                
                Functions shape = null;
                
                Scanner userInput = new Scanner(System.in);
                
               String Option = "";
  
                System.out.print("What type of shape? (S / C / R /T)");
                
                if (userInput.hasNextLine()){
                    String typeofshape = userInput.nextLine();
                    shape =produce.producer(typeofshape);
                    
                    if(shape != null){
                        dofunction(shape);
                    } else System.out.print("Please enter S / C / R / T  next time");

                }
               
                
    }
    
    public static void dofunction(Functions function){
        function.displayArea();
        function.displayPerimeter();
        
    }
			
			
}
