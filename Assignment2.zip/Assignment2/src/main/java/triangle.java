
public class triangle extends Functions {
    public void triangle(){
int s=13;


int area_triangle=s*2/2;
int Perimeter_tirangle=s*3;

    }
}
