/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ANTONIO
 */
public class product {
    // This could be used as a static method if we
	// are willing to give up subclassing it
	
	public Functions producer(String Type){
		
		Functions produce = null;
		
		if (Type.equals("S")){
			
			return new Square();
			
		} else 
                    if (Type.equals("R")){
			
			return new rectangle();
			
		}else
                        if (Type.equals("T")){
			
			return new triangle();
			
		}else
		
		if (Type.equals("C")){
			
			return new Circle();
			
		} else return null;
		
	}
}
