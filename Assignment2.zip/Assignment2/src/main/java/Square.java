
public class Square extends Functions {
    public void Square(){
int s=13;

int area_square=s*s;
int Perimeter_square=s*4;

    }
   
}

