
public class rectangle extends Functions {
     public void rectangle(){
int s=13;
int s2=12;

int area_rectangle=s2*s;
int Perimeter_rectangle=s+s+s2+s2;

    }
}
