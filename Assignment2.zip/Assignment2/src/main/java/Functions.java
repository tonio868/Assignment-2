

public abstract class Functions {
    private double area;
    private double perimeter;
    
    public double getArea() {return area;}
    public void setArea(double newArea) {area = newArea;}  
    
     public double getPerimeter() {return perimeter;}
    public void setPerimeter(double newPerimeter) {area = newPerimeter;} 
    
     public void displayArea(){

         

        System.out.println("This is the Area ="+getArea()  );
        

         

    }
     public void displayPerimeter(){
         System.out.println("This is the Perimeter ="+getPerimeter()  );}

}
